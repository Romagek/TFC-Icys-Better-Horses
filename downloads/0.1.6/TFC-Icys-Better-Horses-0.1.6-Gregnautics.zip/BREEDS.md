# Правила естественного появления пород

| Порода | Температура, °C | Осадки TFC | Вес | Биомы |
|---|---:|---:|---:|---|
| icelandic_horse | -15…8 | 100…500 | 12 | #tfc_icy_horses:uplands |
| haflinger_horse | -8…16 | 100…450 | 9 | #tfc_icy_horses:uplands |
| friesian_horse | 3…19 | 220…500 | 7 | #tfc_icy_horses:open_country |
| shire_horse | 0…18 | 180…500 | 5 | #tfc_icy_horses:open_country |
| clydesdale_horse | -3…16 | 180…500 | 5 | #tfc_icy_horses:open_country |
| belgian_horse | 4…22 | 150…450 | 6 | #tfc_icy_horses:open_country |
| percheron_horse | 1…21 | 130…400 | 6 | #tfc_icy_horses:open_country |
| thoroughbred_horse | 8…25 | 130…400 | 5 | #tfc_icy_horses:open_country |
| andalusian_horse | 12…30 | 60…260 | 8 | #tfc_icy_horses:dry_country |
| arabian_horse | 18…40 | 0…180 | 12 | #tfc_icy_horses:dry_country |
| quarter_horse | 7…30 | 40…260 | 9 | #tfc_icy_horses:dry_country |
| american_paint_horse | 3…28 | 60…300 | 9 | #tfc_icy_horses:dry_country |
| appaloosa_horse | -5…22 | 70…320 | 9 | #tfc_icy_horses:dry_country |
| morgan_horse | -5…24 | 120…450 | 9 | #tfc_icy_horses:open_country |
| mustang_horse | -15…40 | 0…500 | 3 | #tfc_icy_horses:dry_country |

Эти границы определяют естественный спавн. Они не наносят климатический урон существующей лошади.
Правила меняются в config/tfc-icy-horses/breeds.json; затем требуется перезапуск сервера.
